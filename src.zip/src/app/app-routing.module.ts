import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GetproductComponent } from './getproduct/getproduct.component';
import { AddproductComponent } from './addproduct/addproduct.component';
import { BuyproductComponent } from './buyproduct/buyproduct.component';

const routes: Routes = [
  {path:'',component:GetproductComponent},
  {path:'app-getproduct',component:GetproductComponent},
  {path:'app-addproduct', component:AddproductComponent},
  {path:'app-buyproduct', component:BuyproductComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
