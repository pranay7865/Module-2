import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { iproduct } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {


  url="/assets/product.json";
  productList:Array<iproduct>[];
  Balance:number=200000;
  autoId:number=7;
  constructor(private http:HttpClient) {
    
    this.getProduct().subscribe(data=>this.productList=data);
   }

  getProduct():any{
    return this.http.get<iproduct>(this.url);
  }

  buyProduct(product){
    product.quantity--;
    this.Balance-=product.price;
  }

  addProduct(product){
   
    this.productList.push(product);
    this.Balance=this.Balance-100;
    alert(`100 RS Deducted as Service charge. Current Balance ${this.Balance}`);
    this.autoId++;
  }
}
