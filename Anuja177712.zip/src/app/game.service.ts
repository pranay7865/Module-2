import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Games } from './Games';

@Injectable({
  providedIn: 'root'
})
export class GameService {

  userId:number;
  userName:string;
 userAmount:number;
  gameList:Array<Games>[];
  url="/assets/GameList.json";

  constructor(private http:HttpClient) {
    this.getGameList().subscribe(data=>this.gameList=data);
   }
  
  getGameList():any{
   return this.http.get<Games>(this.url);
  }

  setUserDetails(data){
    this.userId=data.userId;
    this.userName=data.userName;
    this.userAmount=data.userAmount-100;
    console.log(`ID ${this.userId} Name ${this.userName} Amount ${this.userAmount}`);
  }
  
  played(game){
    console.log(game);
    if(this.userAmount>=game.Price)
      this.userAmount=this.userAmount-game.Price;
      else
      alert("You dont have enough balance to play this game");
  }
}
