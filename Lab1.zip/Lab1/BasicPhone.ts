import {Mobile} from './Mobile';

export class BasicPhone extends Mobile{
    static mobileType:string="basic";

    constructor(id:number,name:string,cost:number){
        super();
        this.mobileId=id;
        this.mobileName=name;
        this.mobileCost=cost;
    }
    
    getMobileDetails(){
       
        console.log(`Mobile[ Id: ${this.mobileId}, Name: ${this.mobileName}, Cost: ${this.mobileCost}, Type: ${BasicPhone.mobileType}]\n`);
   
    }
}