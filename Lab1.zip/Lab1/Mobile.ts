export class Mobile{

    mobileId:number;
    mobileName:string;
    mobileCost:number;
    getMobileDetails(){
       
        console.log(`Mobile[ Id: ${this.mobileId}, Name: ${this.mobileName}, Cost: ${this.mobileCost}]\n`);
   
    }
}