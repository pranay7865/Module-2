"use strict";
exports.__esModule = true;
var BasicPhone_1 = require("./BasicPhone");
var SmartPhone_1 = require("./SmartPhone");
var Lab1 = /** @class */ (function () {
    function Lab1() {
        this.bp = [
            new BasicPhone_1.BasicPhone(101, "Nokia 1010", 1000),
            new BasicPhone_1.BasicPhone(102, "Nokia 1011", 1200),
            new BasicPhone_1.BasicPhone(103, "Nokia 1021", 1500),
        ];
        this.sp = [
            new SmartPhone_1.SmartPhone(201, "Redmi note 5", 1000),
            new SmartPhone_1.SmartPhone(202, "Oppo F11", 1200),
            new SmartPhone_1.SmartPhone(203, "Aspire A4", 1500),
        ];
    }
    ;
    ;
    Lab1.prototype.meth = function () {
        console.log("\nBasic Phones: \n");
        for (var _i = 0, _a = this.bp; _i < _a.length; _i++) {
            var phone = _a[_i];
            console.log(phone);
        }
        console.log("\nSmart Phones: \n");
        for (var _b = 0, _c = this.sp; _b < _c.length; _b++) {
            var phone = _c[_b];
            console.log(phone);
        }
    };
    return Lab1;
}());
var l = new Lab1();
l.meth();
