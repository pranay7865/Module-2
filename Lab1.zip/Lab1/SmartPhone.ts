import {Mobile} from './Mobile';

export class SmartPhone extends Mobile{
    static mobileType:string="Smart";

    constructor(id:number,name:string,cost:number){
        super();
        this.mobileId=id;
        this.mobileName=name;
        this.mobileCost=cost;
    }
    //getData():void{
    //    console.log(`Mobile[ Id: ${this.mobileId}, Name: ${this.mobileName}, Cost: ${this.mobileCost}, Type: ${SmartPhone.mobileType}]\n`);
    // }
}