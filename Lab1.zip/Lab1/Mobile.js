"use strict";
exports.__esModule = true;
var Mobile = /** @class */ (function () {
    function Mobile() {
    }
    Mobile.prototype.getMobileDetails = function () {
        console.log("Mobile[ Id: " + this.mobileId + ", Name: " + this.mobileName + ", Cost: " + this.mobileCost + "]\n");
    };
    return Mobile;
}());
exports.Mobile = Mobile;
