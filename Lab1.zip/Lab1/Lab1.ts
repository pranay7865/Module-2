import {BasicPhone} from './BasicPhone';
import {SmartPhone} from './SmartPhone';
 class Lab1{
    
    bp:BasicPhone[]=[
        new BasicPhone(101,"Nokia 1010",1000),
        new BasicPhone(102,"Nokia 1011",1200),
        new BasicPhone(103,"Nokia 1021",1500),
        
    ];;
    sp:SmartPhone[]=[
        new SmartPhone(201,"Redmi note 5",1000),
        new SmartPhone(202,"Oppo F11",1200),
        new SmartPhone(203,"    Aspire A4",1500),
    ];;
   
    meth():void{
        console.log("\nBasic Phones: \n")
        for(let phone of this.bp){
            console.log(phone);
        }
        console.log("\nSmart Phones: \n")
        for(let phone of this.sp){
            console.log(phone);
        }
    }
 
 }
let l:Lab1=new Lab1();
 l.meth();
