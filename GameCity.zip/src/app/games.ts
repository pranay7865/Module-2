export class games
{
    id:number;
    name:string;
    price:number;
}