import { Component, OnInit } from '@angular/core';
import { GameserviceService } from '../gameservice.service';

@Component({
  selector: 'app-game',
  templateUrl: './game.component.html',
  styleUrls: ['./game.component.css']
})
export class GameComponent implements OnInit {

  constructor(private service : GameserviceService) { }

  ngOnInit() {
  }

  play=false;

  setUserDetails(data)
  {
    if(data.userName==""||data.userAddress==""||data.userAmount=="")
    {
      alert("Please fill the details")
    }
    else
    {
      alert("You can now start the playing!!!")
      this.service.setUserDetails(data);
      this.play=true;
    }
  }
}
