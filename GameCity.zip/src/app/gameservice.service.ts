import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {games} from './games';


@Injectable({
  providedIn: 'root'
})

export class GameserviceService {

  userId:number;
  userName:string;
  userAmount:number;
  GameList:Array<games>[];
  url:'./assets/GameList.json';

  constructor(private http : HttpClient) {
    this.getGameList().subscribe(data=>this.GameList=data);
   }

   getGameList():any
   {
    return this.http.get<games>(this.url);
   }

   setUserDetails(data)
   {
     this.userId=data.userId;
     this.userName=data.userName;
     this.userAmount=data.userAmount;
     console.log('ID $(this.userId) Name $(this.userName) Amount $(this.userAmount)')
   }

   played(game)
   {
    if(this.userAmount>=game.Price)
    {
      this.userAmount=this.userAmount-game.Price;
    }
    else
    {
      alert("You don't have enough balance to play games.")
    }
   }
}
