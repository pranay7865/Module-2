package com.cg.tms.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.dto.TicketBean;

public class TestDAO {

	TicketDAOImpl obj=new TicketDAOImpl();
	TicketBean ticketBean=new TicketBean("234","tc001","Unable to install Outlook","1","new","1 April 2019 10:56");
	@Test
	public void testRaiseNewTicket(){
		obj.raiseNewTicket(ticketBean);
		assertEquals(true,ticketBean);
	}
	
}
